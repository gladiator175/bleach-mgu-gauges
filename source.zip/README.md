# Bleach Cluster

Hollow Mask is the sole custom theme. The cluster starts switched off.
