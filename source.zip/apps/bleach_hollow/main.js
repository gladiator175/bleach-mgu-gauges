'use strict';
/**
 * Cluster Themes: redraws the iDrive 7 instrument cluster (the 1920x720 "panel" target) through cluster-render.
 *
 * The center screen is the app's own page (shared/page.js, a canvas screen): the themes with their
 * pictures, which drive mode shows which, and the settings. Each choice is saved in the app's data/settings.json
 * by the kit; the shared engine (hud.js) listens and redraws at once. It keeps running after the page is
 * closed (OAP apps stay up in the background), so the page is only needed for changes. The kit's own
 * settings list stays one tap away (the bar's All settings).
 */
const mgu = require('./kit/mgu');
const HudApp = require('./hud');
const Page = require('./page');
const crypto = require('crypto');
const EXPECTED_VIN_HASH = '6c9676b9daca3beec12e03a3b505cc913311e07e9f1dc2ade50b8b56d2d9fc8d';
function ownerVehicle() { let v=process.env.VIN||''; process.argv.forEach((x,i)=>{if(x==='--VIN')v=process.argv[i+1]||'';else if(x.indexOf('--VIN=')===0)v=x.slice(6);});v=String(v).trim().toUpperCase();return /^[A-HJ-NPR-Z0-9]{17}$/.test(v)&&crypto.createHash('sha256').update(v).digest('hex')===EXPECTED_VIN_HASH; }


mgu.run({
    start(ctx) {
        if (!ownerVehicle()) {
            ctx.log.warn("Bleach Cluster: vehicle identity missing or different; renderer not started");
            const cv=ctx.canvas(1600,520).clear("#000000");cv.text("Paired BMW required",800,220,40,"#ffffff",{align:"center"});cv.text("This app cannot verify its owner vehicle",800,285,26,"#ffffff",{align:"center"});ctx.ui.image("MAIN_GFX",cv);return;
        }
        ctx.ui.onClick('BTN_TOGGLE', () => ctx.settings.set('enabled', ctx.settings.get('enabled') !== true));
        let hud;
        try {
            hud = new HudApp(ctx);
        } catch (e) {
            // nothing drawn, but stay up: an exit here would count as a crash on the car
            ctx.log.error('Cluster failed to start: ' + (e && e.stack || e));
            return;
        }
        hud.start();
        new Page(ctx, hud, {
            title: ctx.spec.title, what: 'cluster',
            look: { name: 'Themes', style: 'hero', tags: { hollow_mask: "Hollow Mask", hollow_ichigo: "Hollow Ichigo" } },
            tabs: ['look', 'readouts', 'map', 'alerts', 'gmeter', 'settings'],
            settings: ['enabled', 'engineOffDisplay', 'units', 'clock', 'timeZone', 'tankLitres', 'redline', 'shiftBefore', 'coldGuard', 'showBoost', 'nightDim', 'cameraNotch', 'holiday', 'demo'],
            // the drive mode check's candidates this app's app.json listens to (issue #8; shared/hud.js modeDiagLines)
            modeCheck: [],
        }).start();
        process.on('exit', () => { try { hud.stop(); } catch (e) { /* exiting anyway */ } });
    },
});
