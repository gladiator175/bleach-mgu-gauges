'use strict';
/**
 * Draws text into a widget's RGBA buffer from the pre-baked bitmap fonts in
 * hud/fonts/ (made on the Mac by tools/bake_fonts.py; the car does no font
 * rasterizing). Each font is JSON: glyph metrics plus the atlas as one alpha
 * byte per pixel (base64). We tint the coverage with the requested colour.
 *
 *   drawText(boxW, boxH, text, { font, color, align, spacing, glow }) -> RGBA Buffer (boxW*boxH*4)
 *
 * align: 'left' | 'center' | 'right' within the box; x shifts the start (px). The text's cell top sits at
 * the box top (y = 0). spacing: extra px between characters. glow: 0..1, a soft
 * halo in the same colour under the text (the HUD look); 0 = none.
 * Output is straight (non-premultiplied) RGBA, as cluster-render image layers take it.
 */
const data = require('./hud_data');

const loadedFonts = new Map();
const warnedMissing = new Set();

function loadFont(name) {
    if (loadedFonts.has(name)) return loadedFonts.get(name);
    const metrics = data.json('fonts/' + name + '.json');
    if (!metrics || !metrics.glyphs || !metrics.alpha) throw new Error('font "' + name + '" is missing from hud/fonts');
    const alpha = Buffer.from(metrics.alpha, 'base64');
    if (alpha.length !== metrics.width * metrics.height) throw new Error('font "' + name + '": atlas size does not match');
    const font = { width: metrics.width, alpha, metrics: { size: metrics.size, cellHeight: metrics.cellHeight, baseline: metrics.baseline, glyphs: metrics.glyphs } };
    loadedFonts.set(name, font);
    return font;
}

function glyphOf(font, ch) {
    const g = font.metrics.glyphs[ch];
    if (g) return g;
    if (!warnedMissing.has(ch)) { warnedMissing.add(ch); console.warn('[hud_text] font has no glyph for ' + JSON.stringify(ch)); }
    return font.metrics.glyphs[' '] || { x: 0, y: 0, w: 0, h: 0, ox: 0, advance: 0 };
}

/** Width in px of `text` in `fontName` with `spacing`. */
function measure(text, fontName, spacing) {
    const font = loadFont(fontName);
    const chars = String(text).split('');
    let w = 0;
    chars.forEach((ch, i) => { w += glyphOf(font, ch).advance + (i < chars.length - 1 ? (spacing || 0) : 0); });
    return w;
}

/** Coverage mask (boxW*boxH bytes) of the text laid out in the box. */
function mask(boxW, boxH, text, opts) {
    const font = loadFont(opts.font);
    const spacing = opts.spacing || 0;
    const out = Buffer.alloc(boxW * boxH, 0);
    const width = measure(text, opts.font, spacing);
    let pen = (opts.x || 0) + (opts.align === 'right' ? boxW - width : opts.align === 'center' ? Math.round((boxW - width) / 2) : 0);
    const offY = opts.offsetY || 0;
    for (const ch of String(text)) {
        const g = glyphOf(font, ch);
        const x0 = Math.round(pen + g.ox);       // spacing can be fractional: snap each glyph to a pixel
        for (let y = 0; y < g.h; y++) {
            const dy = y + offY;
            if (dy < 0 || dy >= boxH) continue;
            const srcRow = (g.y + y) * font.width + g.x;
            const dstRow = dy * boxW;
            for (let x = 0; x < g.w; x++) {
                const dx = x0 + x;
                if (dx < 0 || dx >= boxW) continue;
                const a = font.alpha[srcRow + x];
                if (a > out[dstRow + dx]) out[dstRow + dx] = a; // overlapping cells: keep the stronger ink
            }
        }
        pen += g.advance + spacing;
    }
    return out;
}

/** Separable box blur on a coverage mask, radius r, `passes` times (~gaussian at 3). */
function blur(src, w, h, r, passes) {
    let a = Buffer.from(src);
    let b = Buffer.alloc(a.length);
    const n = 2 * r + 1;
    for (let p = 0; p < passes; p++) {
        for (let y = 0; y < h; y++) {           // horizontal
            const row = y * w;
            let sum = 0;
            for (let x = -r; x <= r; x++) sum += a[row + Math.min(w - 1, Math.max(0, x))];
            for (let x = 0; x < w; x++) {
                b[row + x] = (sum / n) | 0;
                sum += a[row + Math.min(w - 1, x + r + 1)] - a[row + Math.max(0, x - r)];
            }
        }
        for (let x = 0; x < w; x++) {           // vertical
            let sum = 0;
            for (let y = -r; y <= r; y++) sum += b[Math.min(h - 1, Math.max(0, y)) * w + x];
            for (let y = 0; y < h; y++) {
                a[y * w + x] = (sum / n) | 0;
                sum += b[Math.min(h - 1, y + r + 1) * w + x] - b[Math.max(0, y - r) * w + x];
            }
        }
    }
    return a;
}

const RAINBOW = [[221, 53, 66], [231, 133, 43], [234, 201, 63],
    [84, 218, 100], [49, 187, 231], [91, 126, 233], [203, 86, 231]];

/** Map rainbow colors across the visible ink so short badges get the full spectrum. */
function rainbowColumns(mask, width, phase) {
    let left = width, right = -1;
    for (let i = 0; i < mask.length; i++) {
        if (!mask[i]) continue;
        const x = i % width;
        left = Math.min(left, x);
        right = Math.max(right, x);
    }
    const colors = [];
    for (let x = left; x <= right; x++) {
        const position = (x - left) / Math.max(1, right - left);
        const count = RAINBOW.length;
        const f = ((position - phase + 1) % 1) * count;
        const stop = Math.floor(f) % count;
        const t = f - Math.floor(f);
        const before = RAINBOW[(stop + count - 1) % count];
        const a = RAINBOW[stop];
        const b = RAINBOW[(stop + 1) % count];
        const after = RAINBOW[(stop + 2) % count];
        // A periodic Catmull–Rom spline keeps the color slope continuous across stops.
        colors[x] = a.map((start, i) => {
            const end = b[i];
            const startSlope = (end - before[i]) / 2;
            const endSlope = (after[i] - start) / 2;
            const value = start + t * (startSlope + t * (3 * (end - start)
                - 2 * startSlope - endSlope + t * (2 * (start - end) + startSlope + endSlope)));
            return Math.round(Math.max(0, Math.min(255, value)));
        });
    }
    return colors;
}

function outlineCoverage(mask, width, height, x, y) {
    if (x === 0 || y === 0 || x === width - 1 || y === height - 1) return 0;
    let coverage = 0;
    for (let dy = -2; dy <= 2; dy++) {
        for (let dx = -2; dx <= 2; dx++) {
            if (dx * dx + dy * dy > 5) continue;
            const px = x + dx, py = y + dy;
            if (px >= 0 && px < width && py >= 0 && py < height) {
                coverage = Math.max(coverage, mask[py * width + px]);
            }
        }
    }
    return coverage / 255;
}

function drawText(boxW, boxH, text, opts) {
    return tint(mask(boxW, boxH, text, opts), boxW, boxH, opts);
}

/** Colour a coverage mask (plus optional glow) into straight RGBA. opts: color, color2 (bottom, for a gradient), glow, font. */
function tint(m, boxW, boxH, opts) {
    const color = opts.color || [255, 255, 255, 255];
    let halo = null;
    const glow = opts.glow || 0;
    if (glow > 0) {
        const r = Math.max(2, Math.round(loadFont(opts.font).metrics.size / 24));
        halo = blur(m, boxW, boxH, r, 2);
    }
    const out = Buffer.alloc(boxW * boxH * 4, 0);
    const ca = color[3] / 255;
    const c2 = opts.color2;          // optional: the colour at the bottom of the box (a top-to-bottom gradient)
    const rainbow = opts.rainbow ? rainbowColumns(m, boxW, opts.rainbowPhase || 0) : null;
    let rowC = color, row = -1;
    for (let i = 0; i < m.length; i++) {
        let a = m[i] / 255;
        if (halo) a = a + (1 - a) * (halo[i] / 255) * glow; // glyph over its own halo
        const under = rainbow && a < 1
            ? outlineCoverage(m, boxW, boxH, i % boxW, Math.floor(i / boxW)) * (1 - a) : 0;
        const coverage = a + under;
        if (coverage <= 0) continue;
        if (c2) {
            const y = Math.floor(i / boxW);
            if (y !== row) { row = y; const f = boxH > 1 ? y / (boxH - 1) : 0; rowC = [0, 1, 2].map((j) => Math.round(color[j] + (c2[j] - color[j]) * f)); }
        }
        const o = i * 4;
        const ink = (rainbow && rainbow[i % boxW]) || rowC;
        out[o] = Math.round((ink[0] * a + 10 * under) / coverage);
        out[o + 1] = Math.round((ink[1] * a + 16 * under) / coverage);
        out[o + 2] = Math.round((ink[2] * a + 31 * under) / coverage);
        out[o + 3] = Math.round(coverage * ca * 255);
    }
    return out;
}

module.exports = { drawText, mask, tint, measure, loadFont };
