/* Original scene images and legacy portraits. Nearest-neighbor sampling preserves pixel edges. */
'use strict';
const zlib=require('zlib'),data=require('./hud_data');
const cache=Object.create(null);
function paintSprite(name,w,h){
 const spec=data.json('art/'+name+'.json');
 if(!spec||!spec.z||!(spec.w>0&&spec.h>0))throw Error('Missing image '+name);
 const key=name+':'+w+':'+h;if(cache[key])return cache[key];
 const px=zlib.inflateSync(Buffer.from(spec.z,'base64'));
 if(px.length!==spec.w*spec.h*4)throw Error('Invalid image '+name);
 if(w===spec.w&&h===spec.h){cache[key]=px;return px;}
 const out=Buffer.alloc(w*h*4,0),scale=Math.min(w/spec.w,h/spec.h),dw=Math.max(1,Math.floor(spec.w*scale)),dh=Math.max(1,Math.floor(spec.h*scale)),ox=Math.floor((w-dw)/2),oy=Math.floor((h-dh)/2);
 for(let y=0;y<dh;y++)for(let x=0;x<dw;x++){const a=(Math.min(spec.h-1,Math.floor(y/scale))*spec.w+Math.min(spec.w-1,Math.floor(x/scale)))*4,b=((oy+y)*w+ox+x)*4;px.copy(out,b,a,a+4);}
 cache[key]=out;return out;
}
module.exports={paintSprite, animateSprite};

/** Animate RGB only, preserving the supplied art's edges, cutouts and alpha. */
function animateSprite(name, w, h, animation, phase) {
    const source = paintSprite(name, w, h);
    const out = Buffer.from(source);
    const pulse = (1 - Math.cos(phase * 2 * Math.PI)) / 2;
    const greenPulse = (1 - Math.cos((phase + 0.5) * 2 * Math.PI)) / 2;
    for (let i = 0; i < out.length; i += 4) {
        if (out[i + 3] === 0) continue;
        if (animation === 'pulseRed') {
            out[i] = Math.round(166 + 16 * pulse);
            out[i + 1] = 8;
            out[i + 2] = 6;
            continue;
        }
        if (animation !== 'letterGlow') continue;
        // The original blue and green letters take turns glowing. Scaling RGB
        // together preserves their hue and leaves all other lettering untouched.
        const r = source[i], g = source[i + 1], b = source[i + 2];
        const blue = b > r + 35 && b > g + 15;
        const green = g > r + 35 && g > b + 25;
        if (!blue && !green) continue;
        const gain = 0.78 + 0.22 * (blue ? pulse : greenPulse);
        out[i] = Math.round(r * gain);
        out[i + 1] = Math.round(g * gain);
        out[i + 2] = Math.round(b * gain);
    }
    return out;
}

function smoothStep(value) {
    const t = Math.max(0, Math.min(1, value));
    return t * t * (3 - 2 * t);
}

/** Paint the approved half-resolution ghost paths behind the gauge layers. */
function paintGhostRoutes(w, now) {
    const { routes } = data.json('art/' + w.sprite + '.json');
    const width = 36, height = 34;
    const tile = paintSprite(w.sprite, width, height);
    const pixels = Buffer.alloc(w.iw * w.ih * 4);
    routes.forEach((route, index) => {
        const travel = (now / route.duration + index * 0.23) % route.paths.length;
        const points = route.paths[Math.floor(travel)];
        const p = travel % 1;
        const along = p * (points.length - 1);
        const segment = Math.floor(along);
        const mix = along - segment;
        const [x0, y0] = points[segment];
        const [x1, y1] = points[segment + 1];
        const left = Math.round(x0 + (x1 - x0) * mix) - width / 2 - w.x / 2;
        const top = Math.round(y0 + (y1 - y0) * mix - 9 * Math.sin(Math.PI * mix)) - height / 2 - w.y / 2;
        const opacity = smoothStep(p / 0.17) * smoothStep((1 - p) / 0.15);
        for (let y = Math.max(0, -top); y < Math.min(height, w.ih - top); y++) {
            for (let x = Math.max(0, -left); x < Math.min(width, w.iw - left); x++) {
                const source = (y * width + (x1 > x0 ? width - 1 - x : x)) * 4;
                const alpha = Math.round(tile[source + 3] * opacity);
                if (alpha === 0) continue;
                const at = ((top + y) * w.iw + left + x) * 4;
                const under = pixels[at + 3] * (1 - alpha / 255);
                const combined = alpha + under;
                for (let c = 0; c < 3; c++) {
                    pixels[at + c] = Math.round((tile[source + c] * alpha + pixels[at + c] * under) / combined);
                }
                pixels[at + 3] = Math.round(combined);
            }
        }
    });
    return pixels;
}

module.exports.paintGhostRoutes = paintGhostRoutes;
